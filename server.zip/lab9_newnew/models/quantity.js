const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ConfigSchema = new Schema({
  quantity: String,
  time:String,
  type:String
});

const ConfigModel = mongoose.model('quantity', ConfigSchema);

module.exports = ConfigModel;