const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ConfigSchema = new Schema({
  watertimer: String,
  quantity: String,
  bugkiller: String,
  time:String,
  type:String
});

const ConfigModel = mongoose.model('configs', ConfigSchema);

module.exports = ConfigModel;