const Env = require('./models/env');
const Status = require('./models/devicestatus');
const Don = require('./models/quantity');
const Water = require('./models/watertimer');
const Config = require('./models/configs');///////////////////////////

const express = require('express');

var app = express();


app.use(express.static('uploads'));
var qs = require('querystring');



const mongoose = require('mongoose');
const hbs = require('hbs');
var path = require('path');
const bodyParser = require('body-parser');
const axios = require('axios');

const Schema = mongoose.Schema;
const multer = require('multer');

const Image = require('./models/image'); // เรียกใช้โมดูล Image

// Multer configuration
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/iot_db', {
  useNewUrlParser: true
});







app.use(express.urlencoded());
app.use(express.json());



app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'hbs');
hbs.registerPartials(__dirname + '/views')
const static_path = path.join(__dirname, "/public")
app.use(express.static(static_path));
console.log(static_path);
const WebSocket = require('ws');
const { env } = require('process');
hbs.registerHelper('iff', function (a, operator, b, opts) {
  var bool = false;
  switch (operator) {
    case '==':
      bool = a == b;
      break;
    case '>':
      bool = a > b;
      break;
    case '<':
      bool = a < b;
      break;
    case '!=':
      bool = a != b;
      break;
    default:
      throw "Unknown operator " + operator;
  }

  if (bool) {
    return opts.fn(this);
  } else {
    return opts.inverse(this);
  }
});

hbs.registerHelper('ifCond', function (v1, options) {
  if (v1 % 3 == 2) {
    return options.fn(this);
  }
  return options.inverse(this);
});

hbs.registerHelper('iftime', function (v1, v2, options) {
  if (v1 == v2) {
    return options.fn(this);
  }
  return options.inverse(this);
});

hbs.registerHelper('forlist', function (v1, v2, options) {
  var i;
  var cmd = "<option selected value=" + v2 + ">" + (v2) + "</option>";
  for (i = 0; i < v1.length; i++) {
    if (v1[i] != v2) {
      cmd += "<option value=" + v1[i] + ">" + (v1[i]) + "</option>"

    }

  }
  return cmd;
});

const port = 3000;
var hum = "30";


app.listen(port, () => {
  console.log(`Listening at http://192.168.109.101:3000`);
});



var appPort = 3001;
// Normal HTTP configuration
//let http = require('http').Server(app;

//const wss = new WebSocket.Server({ server:http });
const wss = new WebSocket.Server({ port: appPort });
wss.on('connection', async function connection(wssLocal) {
  console.log('A new client Connected!111111111111111111 11111111111111111111111111');

  const sort = { time: -1 }; // Define sort variable here

  // Fetch the latest environmental data
  const envs = await Env.find({}).sort(sort).limit(1);
  console.log("AAAAAAAAAAAAAAAAAAAAAAAAAA")
  console.log(envs);
  console.log("BBBBBBBBBBBBBBBBBBBB")

  // Prepare the data to send to the client
  const dataToSend = {
    temperature: envs[0].temperature,
    humidity: envs[0].humidity,
    EC: envs[0].EC,
    PH: envs[0].PH,
    nitrogen: envs[0].nitrogen,
    phosphorus: envs[0].phosphorus,
    potassium: envs[0].potassium
  };

  // Convert the data to JSON format
  const jsonData = JSON.stringify(dataToSend);

  // Send the data to all connected clients
  wss.clients.forEach(function each(client) {
    if (client.readyState === WebSocket.OPEN) {
      console.log(jsonData);
      client.send(jsonData);
    }
  });
});


mongoose.connect('mongodb://localhost:27017/iot_db', {
  useNewUrlParser: true
});

app.get('/', function (req, res, next) {
  res.render('index', { title: 'Express' });
});
app.get('/temp', (req, res) => {
  var temp = 10;
  var temperature = "temp=" + temp
  res.send(temperature);
});
app.get('/tracking', async (req, res) => {

  //const log = await managementlog.find();
  //console.log(log)
  const log = await Status.find();
  //var log={};
  //log=[{"type": "Delete","devicename": "pump1", "username":"admin","action": "ON","time": "00"}]
  res.render("tracking", { log: log })

});

app.get('/aboutus', async (req, res) => {

  //const log = await managementlog.find();
  //console.log(log)
  const log = await Status.find();
  //var log={};
  //log=[{"type": "Delete","devicename": "pump1", "username":"admin","action": "ON","time": "00"}]
  res.render("aboutus", { log: log })

});

app.get('/upload', async (req, res) => {
  // ดึงข้อมูลจากฐานข้อมูล
  const log = await Status.find();
  // ส่งคำขอกลับด้วยการ render หน้า HTML และข้อมูลที่ต้องการแสดงผล
  res.render("upload", { log: log });
});


app.get('/setting', async (req, res) => {

  //const log = await managementlog.find();
  //console.log(log)
  const log = await Status.find();
  //var log={};
  //log=[{"type": "Delete","devicename": "pump1", "username":"admin","action": "ON","time": "00"}]
  res.render("setting", { log: log })

});


app.get('/getenvs', async (req, res) => {
  const envs = await Env.findOne({});
  res.json(envs);
});
app.post('/sethum', (req, res) => {
  var data = ''
  req.on('data', chunk => {
    console.log('A chunk of data has arrived: ', chunk);
    data = data + chunk;
    console.log(data);
    hum = data;
  });
  req.on('end', () => {
    console.log('No more data');
  })
  res.sendStatus(200);
});

var mqtt = require('mqtt');

const MQTT_SERVER = "m15.cloudmqtt.com";
const MQTT_PORT = "12987";
//if your server don't have username and password let blank.
const MQTT_USER = "cyejnmdr";
const MQTT_PASSWORD = "Is7roaqnQX09";

// Connect MQTT
var client = mqtt.connect({
  host: MQTT_SERVER,
  port: MQTT_PORT,
  username: MQTT_USER,
  password: MQTT_PASSWORD
});

client.on('connect', function () {
  // Subscribe any topic
  console.log("MQTT Connect");
  client.subscribe('envs', function (err) {
    if (err) {
      console.log(err);
    }
  });
});

// Receive Message and print on terminal
client.on('message', async function (topic, message) {
  // message is Buffer
  console.log(message.toString());
  var temp = ['1', '2', '3', '4'];
  var temps = message.toString().split(",");
  axios.post('http://192.168.109.101:3000/envs', {
    humidity: temps[0],
    temperature: temps[1],
    EC: temps[2],
    PH: temps[3],
    nitrogen: temps[4],
    phosphorus: temps[5],
    potassium: temps[6]
  })
    .then(function (response) {
      console.log(response);
    })
    .catch(function (error) {
      console.log(error);
    });
  console.log(message.toString());
});

setInterval(() => {
  //client.publish("pump", "hello from NodeJS");
}, 5000);






app.use(express.json());
// mock data
const products = [{}];

app.post('/pump', async (req, res) => {
  const payload = req.body;

  var date_ob = new Date();
  /*const saveEnvs = new Env({
    status: payload.status,
    device: "pump",
    time: date_ob,
    
  })
  //const product = new Env(payload);
  await saveEnvs.save(); */
  //send MQTT broker;  publisher (nodejs)
  console.log(payload.status);

  client.publish("testiotsub1", payload.status, { qos: 0, retain: false }, (error) => {
    if (error) {
      console.error(error)
    }
  })

  res.status(201).end();
});


app.post('/envs', async (req, res) => {
  const payload = req.body;
  console.log(payload);
  var date_ob = new Date();
  const saveEnvs = new Env({
    temperature: payload.temperature,
    humidity: payload.humidity,
    time: date_ob,
    EC: payload.EC,
    PH: payload.PH,
    nitrogen: payload.nitrogen,
    phosphorus: payload.phosphorus,
    potassium: payload.potassium,
    type: payload.type

  })
  //const product = new Env(payload);
  await saveEnvs.save();
  const query = {};
  const sort = { time: -1 };
  const limit = 1;
  const envs = await Env.find({}).sort(sort).limit(1);

  console.log(envs);
  var test = [{ "temperature": envs[0].temperature, 
  "humidity": envs[0].humidity, 
  "EC": envs[0].EC, 
  "PH": envs[0].PH,
  "nitrogen": envs[0].nitrogen,
  "phosphorus": envs[0].phosphorus,
  "potassium": envs[0].potassium }];


  var statusAllJson = JSON.stringify(test);
  wss.clients.forEach(function each(client) {
    if (client.readyState === WebSocket.OPEN) {

      console.log(statusAllJson);
      client.send(statusAllJson);

    }
  });


  res.status(201).end();
});

app.post('/status', async (req, res) => {
  const payload = req.body;
  console.log(payload);
  
    client.publish("Pump_5g", payload.status, function (err) {
      if (!err) {
          console.log('Message sent successfully');
      } else {
          console.error('Error publishing message:', err);
      }
      // Close connection after publishing
      // client.end();
  })
  
  var date_ob = new Date();
  const saveEnvs = new Status({
    time: date_ob,
    type: payload.type,
    status: payload.status
  });

  await saveEnvs.save();

  res.status(201).end();
});

app.post('/status_ins', async (req, res) => {
  const payload = req.body;
  console.log(payload);
  
    client.publish("Light_5g", payload.status, function (err) {
      if (!err) {
          console.log('Message sent successfully');
      } else {
          console.error('Error publishing message:', err);
      }
      // Close connection after publishing
      // client.end();
  })
  
  var date_ob = new Date();
  const saveEnvs = new Status({
    time: date_ob,
    type: payload.type,
    status: payload.status
  });

  await saveEnvs.save();

  res.status(201).end();
});


app.post('/water', async (req, res) => {
  const payload = req.body;
  console.log(payload);
  var date_ob = new Date();
  const saveEnvs = new Water({
    time: date_ob,
    status: payload.status,
    time: payload.time,
    type: payload.type

  })
  //const product = new Env(payload);
  await saveEnvs.save();

  res.status(201).end();
});

////////////////////////////////////////////////////////////////////////////

app.post('/configs', async (req, res) => {
  const payload = req.body;
  console.log(payload);
  var date_ob = new Date();
  const saveEnvs = new Config({
    time: date_ob,
    watertimer: payload.watertimer,
    quantity: payload.quantity,
    bugkiller: payload.bugkiller,
    time: payload.time,
    type: payload.type

  })
  //const product = new Env(payload);F
  await saveEnvs.save();

  res.status(201).end();
});

app.post('/quantity', async (req, res) => {
  const payload = req.body;
  
  var date_ob = new Date();
  const saveEnvs = new Confir({
    time: date_ob,
    quantity: payload.quantity,
    time: payload.time,
    type: payload.type
  })
  //const product = new Env(payload);
  await saveEnvs.save();


  


  res.status(201).end();
});

app.post("/ajax_updateWaterTimer", async (req, res) => {
  //console.log(req);
  console.log("EEEEEEEEEEEEEEEEEEEEEE =" + req.body.id);
  console.log("EEEEEEEEEEEEEEEEEEEEEE =" + req.body.waterTimer);
  try {

    const payload = req.body;
    console.log(payload);

    var date_ob = new Date();
    const saveConfig = new Don({
      waterTimer: payload.waterTimer,
      status: payload.status,
      time: date_ob,

    })
    await saveConfig.save();

    console.log("aaaaaaaaaaaaaaaaaaaaaaaa");

    return res.status(200).json({ status: true })
  } catch (error) {
    res.send("Set Status error");
  }
});

app.post('/toggle-water-timer', (req, res) => {
  const status = req.body.status;
});

app.post('/toggle-autofill', (req, res) => {
  const status = req.body.status;
});

app.post('/toggle-bugkiller', (req, res) => {
  const status = req.body.status;
});


////////////////////////



// Define the route for handling image uploads
app.post('/upload_image', upload.single('image'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }

  // Save image data to MongoDB
  const newImage = new Image({
    filename: req.file.filename,
    mimetype: req.file.mimetype,
    size: req.file.size,
    path: req.file.path
  });

  try {
    await newImage.save();
    res.status(201).json({ message: 'Image uploaded successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to save image to database' });
  }
});



app.get('/images', async (req, res) => {
  try {
    const images = await Image.find();
    res.json(images);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to fetch images' });
  }
});

// Route เพื่อให้เซิร์ฟ URL ของรูปภาพล่าสุด
app.get('/latest_image_url', async (req, res) => {
  try {
    const latestImage = await Image.findOne().sort({ uploadedAt: -1 }); // ค้นหารูปภาพล่าสุด
    const latestImageUrl = latestImage ? latestImage.filename : ''; // รับชื่อไฟล์ของรูปภาพล่าสุด
    res.send(`/uploads/${latestImageUrl}`);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'ไม่สามารถดึง URL รูปภาพล่าสุดได้' });
  }
});



// document.addEventListener("DOMContentLoaded", function() {
//   // เรียก API endpoint เพื่อดึง URL ของรูปภาพล่าสุด
//   fetch("/latest_image_url")
//     .then(response => response.json())
//     .then(url => {
//       // สร้าง element <img> และกำหนด URL ของรูปภาพล่าสุดให้เป็น src attribute
//       var imgElement = document.createElement("img");
//       imgElement.src = url;
//       // หาส่วนที่มี class="image-gallery"
//       var imageGallery = document.querySelector(".image-gallery");
//       // เพิ่ม element <img> ที่สร้างเข้าไปในส่วนที่มี class="image-gallery"
//       imageGallery.appendChild(imgElement);
//     })
//     .catch(error => console.error(error));
// });


/////////////////////
app.post('/upload_image_and_text', upload.single('image'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }

  // Save image data and text data to MongoDB
  const newImage = new Image({
    filename: req.file.filename,
    mimetype: req.file.mimetype,
    size: req.file.size,
    path: req.file.path,
    textData: req.body.additionalData // Assuming the text data is sent in the request body
  });

  try {
    await newImage.save();
    res.status(201).json({ message: 'Image and text uploaded successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to save image and text to database' });
  }
});


