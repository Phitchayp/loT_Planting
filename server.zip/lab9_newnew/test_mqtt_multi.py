import random
import time
import multiprocessing
from paho.mqtt import client as mqtt_client

BROKER = 'm15.cloudmqtt.com'
PORT = 12987
CLIENT_ID = f'python-mqtt-{random.randint(0, 100)}' #change
USERNAME = 'cyejnmdr'
PASSWORD = 'Is7roaqnQX09'

def connect_mqtt() -> mqtt_client:
    """Connect to MQTT Broker."""
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT Broker!")
        else:
            print("Failed to connect, return code:", rc)

    client = mqtt_client.Client(CLIENT_ID)
    client.username_pw_set(USERNAME, PASSWORD)
    client.on_connect = on_connect
    client.connect(BROKER, PORT)
    return client

# def publish(client):
#     """Publish messages to the 'envs' topic."""
#     msg_count = 0
#     while msg_count < 100:  # Loop until msg_count reaches 100
#         time.sleep(3)
#         topic = "envs"
#         msg = f"{msg_count+1},{msg_count+2},{msg_count+3},{msg_count+4},{msg_count+5},{msg_count+6},{msg_count+7}"
#         result = client.publish(topic, msg)
#         if result.rc != mqtt_client.MQTT_ERR_SUCCESS:
#             print(f"Failed to publish message: {msg}")
#         else:
#             print(f"Published message: {msg}")
#         msg_count += 1


def publish(client):
    """Publish messages to the 'envs' topic."""
    msg_count = 0
    while msg_count < 100:  # Loop until msg_count reaches 100
        time.sleep(3)
        topic = "envs"
        additional_variable = random.randint(0, 14) 
        msg = f"{msg_count+1},{additional_variable},{msg_count+2},{msg_count+3},{msg_count+4},{msg_count+5},{msg_count+6}"
        result = client.publish(topic, msg)
        if result.rc != mqtt_client.MQTT_ERR_SUCCESS:
            print(f"Failed to publish message: {msg}")
        else:
            print(f"Published message: {msg}")
        msg_count += 1



def subscribe(client: mqtt_client):
    """Subscribe to the 'testiotsub' topic."""
    client.subscribe("testiotsub")
    client.on_message = on_message

def on_message(client, userdata, msg):
    """Callback function for incoming messages."""
    print(f"Received `{msg.payload.decode()}` from `{msg.topic}` topic")

def run():
    """Main function to connect, publish, and subscribe."""
    client = connect_mqtt()

    p1 = multiprocessing.Process(target=publish, args=(client,))
    p2 = multiprocessing.Process(target=subscribe, args=(client,))

    p1.start()
    p2.start()

    try:
        p1.join()
        p2.join()
    except KeyboardInterrupt:
        print("Exiting...")

if __name__ == '__main__':
    run()
