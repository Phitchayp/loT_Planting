# import RPi.GPIO as GPIO
# import paho.mqtt.client as mqtt
# import time

# # กำหนดข้อมูลสำหรับการเชื่อมต่อ MQTT
# mqtt_broker_address = "04b676ae30984df98cdf25ea13faaadf.s1.eu.hivemq.cloud"
# mqtt_port = 8883
# mqtt_username = "hivemq.webclient.1710070635593"
# mqtt_password = "ecS.7R8Y:39hUvDC#r%n"

# # กำหนด GPIO
# GPIO.setmode(GPIO.BCM)
# led_pin = 23
# GPIO.setup(led_pin, GPIO.OUT)

# # ฟังก์ชันเมื่อมีการเชื่อมต่อ MQTT
# def on_connect(client, userdata, flags, rc):
#     print("Connected with result code "+str(rc))
#     client.subscribe("led/control")

# # ฟังก์ชันเมื่อได้รับข้อมูล MQTT
# def on_message(client, userdata, msg):
#     print(msg.topic+" "+str(msg.payload))
#     if msg.payload == b'ON':
#         GPIO.output(led_pin, GPIO.HIGH)
#     elif msg.payload == b'OFF':
#         GPIO.output(led_pin, GPIO.LOW)

# # กำหนด MQTT client
# client = mqtt.Client()
# client.username_pw_set(mqtt_username, mqtt_password)
# client.on_connect = on_connect
# client.on_message = on_message

# # เชื่อมต่อ MQTT broker
# client.connect(mqtt_broker_address, mqtt_port, 60)

# # เริ่มต้นการรับข้อมูล MQTT
# client.loop_start()

# try:
#     while True:
#         time.sleep(1)
# except KeyboardInterrupt:
#     GPIO.cleanup()
#     client.disconnect()
#     client.loop_stop()

import RPi.GPIO as GPIO
import paho.mqtt.client as mqtt

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO_LIGHT = 23
GPIO_PUMP = 24
GPIO_FERT = 4
GPIO.setup(GPIO_LIGHT, GPIO.OUT)
GPIO.setup(GPIO_PUMP, GPIO.OUT)
GPIO.setup(GPIO_FERT, GPIO.OUT)

broker = 'm15.cloudmqtt.com'
port = 12987
topic_light = "Light_5g"
topic_pump = "Pump_5g"
topic_fert = "Fert_5g"
username = 'cyejnmdr'
password = 'Is7roaqnQX09'

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connected to MQTT Broker!")
    else:
        print("Failed to connect, return code %d\n", rc)
    client.subscribe([(topic_light, 0), (topic_pump, 0)])

def on_message(client, userdata, msg):
    print("Received message: "+msg.payload.decode())
    if msg.topic == topic_light:
        if msg.payload.decode() == "on":
            GPIO.output(GPIO_LIGHT, GPIO.LOW)  # เปิด
        elif msg.payload.decode() == "off":
            GPIO.output(GPIO_LIGHT, GPIO.HIGH)  # ปิด
    elif msg.topic == topic_pump:
        if msg.payload.decode() == "on":
            GPIO.output(GPIO_PUMP, GPIO.LOW)  # เปิด
        elif msg.payload.decode() == "off":
            GPIO.output(GPIO_PUMP, GPIO.HIGH)  # ปิด
    elif msg.topic == topic_fert:
        if msg.payload.decode() == "on":
            GPIO.output(GPIO_FERT, GPIO.LOW)  # เปิด
        elif msg.payload.decode() == "off":
            GPIO.output(GPIO_FERT, GPIO.HIGH)  # ปิด

client = mqtt.Client()
client.username_pw_set(username, password)
client.on_connect = on_connect
client.on_message = on_message

client.connect(broker, port, 60)

client.loop_forever()


# import RPi.GPIO as GPIO
# import paho.mqtt.client as mqtt

# GPIO.setmode(GPIO.BCM)
# GPIO.setwarnings(False)
# GPIO_LIGHT = 23
# GPIO_PUMP = 24
# GPIO.setup(GPIO_LIGHT, GPIO.OUT)
# GPIO.setup(GPIO_PUMP, GPIO.OUT)


# broker = 'm15.cloudmqtt.com'
# port = 12987
# topic_light = "Light_5g"
# topic_pump = "Pump_5g"
# username = 'cyejnmdr'
# password = 'Is7roaqnQX09'


# def on_connect(client, userdata, flags, rc):
#     if rc == 0:
#         print("Connected to MQTT Broker!")
#     else:
#         print("Failed to connect, return code %d\n", rc)
#     client.subscribe([(topic_light, 0), (topic_pump, 0)])


# def on_message(client, userdata, msg, ):
#     print("Received message: "+msg.payload.decode())
#     if msg.topic == topic_light:
#         if msg.payload.decode() == "on":
#             GPIO.output(GPIO_LIGHT, GPIO.LOW)  # เปิด
#         elif msg.payload.decode() == "off":
#             GPIO.output(GPIO_LIGHT, GPIO.HIGH)  # ปิด
#     elif msg.topic == topic_pump:
#         if msg.payload.decode() == "on":
#             GPIO.output(GPIO_PUMP, GPIO.LOW)  # เปิด
#         elif msg.payload.decode() == "off":
#             GPIO.output(GPIO_PUMP, GPIO.HIGH)  # ปิด

# client = mqtt.Client()
# client.username_pw_set(username, password)
# client.on_connect = on_connect
# client.on_message = on_message


# client.connect(broker, port, 60)


# client.loop_forever()
