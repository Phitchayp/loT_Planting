import RPi.GPIO as GPIO
import paho.mqtt.client as mqtt

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO_LIGHT = 23
GPIO_PUMP = 24
GPIO_FERT = 4
GPIO.setup(GPIO_LIGHT, GPIO.OUT)
GPIO.setup(GPIO_PUMP, GPIO.OUT)
GPIO.setup(GPIO_FERT, GPIO.OUT)

broker = 'm15.cloudmqtt.com'
port = 12987
topic_light = "Light_5g"
topic_pump = "Pump_5g"
topic_fert = "Fert_5g"
username = 'cyejnmdr'
password = 'Is7roaqnQX09'

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connected to MQTT Broker!")
    else:
        print("Failed to connect, return code %d\n", rc)
    client.subscribe([(topic_light, 0), (topic_pump, 0)])

def on_message(client, userdata, msg):
    print("Received message: "+msg.payload.decode())
    if msg.topic == topic_light:
        if msg.payload.decode() == "on":
            GPIO.output(GPIO_LIGHT, GPIO.LOW)  # เปิด
        elif msg.payload.decode() == "off":
            GPIO.output(GPIO_LIGHT, GPIO.HIGH)  # ปิด
    elif msg.topic == topic_pump:
        if msg.payload.decode() == "on":
            GPIO.output(GPIO_PUMP, GPIO.LOW)  # เปิด
        elif msg.payload.decode() == "off":
            GPIO.output(GPIO_PUMP, GPIO.HIGH)  # ปิด
    elif msg.topic == topic_fert:
        if msg.payload.decode() == "on":
            GPIO.output(GPIO_FERT, GPIO.LOW)  # เปิด
        elif msg.payload.decode() == "off":
            GPIO.output(GPIO_FERT, GPIO.HIGH)  # ปิด

client = mqtt.Client()
client.username_pw_set(username, password)
client.on_connect = on_connect
client.on_message = on_message

client.connect(broker, port, 60)

client.loop_forever()



